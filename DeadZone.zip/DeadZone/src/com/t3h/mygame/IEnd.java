package com.t3h.mygame;

public interface IEnd {
    void showMenu();
}
