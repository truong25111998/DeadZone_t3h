package com.t3h.mygame.object;

import com.t3h.mygame.Constants;
public class Pad extends Object2D implements Constants {

}
