package com.t3h.mygame.object;

public class ObjMov2D extends Object2D {
}
