package com.t3h.mygame.object;

public class Coin extends Object2D {
}
