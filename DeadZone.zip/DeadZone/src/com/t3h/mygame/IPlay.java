package com.t3h.mygame;

public interface IPlay {
    void showEnd();
}
