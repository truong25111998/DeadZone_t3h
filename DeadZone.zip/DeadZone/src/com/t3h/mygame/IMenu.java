package com.t3h.mygame;
public interface IMenu {
    void showPlay(int mapSize, int level);
}
