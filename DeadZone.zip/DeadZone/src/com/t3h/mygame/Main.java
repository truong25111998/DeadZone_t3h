package com.t3h.mygame;

public class Main {
    public static void main(String[] args) {
        GUI gui = new GUI();
        gui.setVisible(true);

        //Android Studio
        //SDK
        //EMULATOR (ANDROID STUDIO)
        //TAO PROJECT HELLOWORLD

    }
}
